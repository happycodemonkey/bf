#ifndef INPUTFIELD_H
#define INPUTFIELD_H

#include <QString>
#include <QWidget>
#include <QLabel>
#include <QGridLayout>
#include <QPushButton>
#include <QTextEdit>
#include <QApplication>

#include "bf.h"

class InputField : public QWidget {
  
  Q_OBJECT

 public:
  InputField(QWidget * parent = 0);

  public slots:
  void setLabel();

 private:
  QLabel *label;
  QTextEdit *textEdit;
  QGridLayout *layout;
  QPushButton *change;
  QPushButton *quit;
  Bf bf;
};

#endif
