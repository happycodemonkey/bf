#include "inputField.h"

InputField::InputField(QWidget * parent) : QWidget(parent) {
  textEdit = new QTextEdit;
  label = new QLabel;
  layout = new QGridLayout;
  change = new QPushButton("Interpret");
  quit = new QPushButton("Quit");

  layout->addWidget(textEdit, 1, 1, 1, 2);
  layout->addWidget(label, 2, 1, 1 ,2);
  layout->addWidget(change, 3, 1);
  layout->addWidget(quit, 3, 2);
  setLayout(layout);

  connect(quit, SIGNAL(clicked()), qApp, SLOT(quit()));
  connect(change, SIGNAL(clicked()), this, SLOT(setLabel()));
}

void InputField::setLabel() {

  label->setText(QString::fromStdString(bf.interpret(textEdit->toPlainText().toStdString())));
}
