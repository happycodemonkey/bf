#include <QApplication>

#include "inputField.h"

int main(int argc, char* argv[]) {
  QApplication app(argc, argv);

  InputField inputField;
  inputField.show();

  return app.exec();

}
